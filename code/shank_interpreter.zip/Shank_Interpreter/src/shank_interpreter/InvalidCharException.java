package shank_interpreter;


public class InvalidCharException extends Exception {
	
	public InvalidCharException (String message) {
		
		super(message);
		
	}
}
