package shank_interpreter;


import java.util.ArrayList;



public class BuiltInEnd extends FunctionNode {

	public BuiltInEnd (ArrayList<InterpreterDataType> list) {
		super(list);
	}
	
	public void execute(ArrayList<InterpreterDataType> list) {
		
		/*End var end
		end = the last index of this array*/
		
		
		
	}

}
