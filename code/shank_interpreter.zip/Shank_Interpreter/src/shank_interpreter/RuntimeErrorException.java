package shank_interpreter;


public class RuntimeErrorException extends Exception {

	public RuntimeErrorException(String msg) {
		super(msg);
	}
	
}
