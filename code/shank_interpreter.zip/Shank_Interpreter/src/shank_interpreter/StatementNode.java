package shank_interpreter;


public abstract class StatementNode extends Node {

	public abstract String toString();

}
