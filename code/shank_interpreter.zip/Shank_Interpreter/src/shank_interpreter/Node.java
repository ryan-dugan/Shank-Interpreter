package shank_interpreter;


public abstract class Node {
	
	public abstract String toString();	
	
}


