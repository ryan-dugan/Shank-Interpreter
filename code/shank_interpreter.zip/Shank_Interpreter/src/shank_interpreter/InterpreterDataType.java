package shank_interpreter;


public abstract class InterpreterDataType<E> {

	public abstract String toString();
	
	public abstract void FromString(String input);
		
}
