package shank_interpreter;


public class EmptyNode extends Node {

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

}
